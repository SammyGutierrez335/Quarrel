import React, { useState } from "react";
import { useMutation } from "@apollo/client";
import { useHistory } from "react-router-dom";
import Mutations from "../../graphql/mutations";
import * as SessionUtil from "../../util/session_util";
import { withRouter } from "react-router-dom";

const { LOGIN_USER } = Mutations;

const Login = (props) => {
  const history = useHistory();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState([]);

  const [loginUser] = useMutation(LOGIN_USER, {
    onCompleted: (data) => {
      // save auth token + current user
      const { token } = data.login;
      localStorage.setItem("auth-token", token);
      localStorage.setItem("currentUserId", data.login._id);
    
      // also save to cache/local util
      SessionUtil.saveUserToLocalStorage(data.login);

      // redirect
      history.push("/");
    },
    onError: (err) => {
      const errorArray = err.graphQLErrors.map((e) => e.message);
      setErrors(errorArray);
      setTimeout(() => setErrors([]), 5000);
    },
    update: (client, { data }) => {
      if (data && data.login) {
      const { token, _id } = data.login;
      SessionUtil.saveUserToCache(client, data.login);
      localStorage.setItem("auth-token", token);
      localStorage.setItem("currentUserId", _id);
      props.history.push("/");
    
      }
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    loginUser({ variables: { email, password } });
  };

  const handleDemoLogin = (e) => {
    e.preventDefault();
    debugger
    loginUser({
      variables: { email: "demouser@gmail.com", password: "password" },
    });
  };

  return (
    <div>
      {errors.length > 0 && <div className="login-error">{errors}</div>}

      <div className="login-form-box">
        <label className="session-label">Login</label>
        <form className="login-form" onSubmit={handleSubmit}>
          <div className="form_column">
            <input
              className="text_box"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
            />
          </div>
          <div className="form_column">
            <input
              className="text_box"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              type="password"
              placeholder="Password"
            />
          </div>
          <button type="submit" className="form-button">
            Login
          </button>
          <button
            type="button"
            onClick={handleDemoLogin}
            className="demo-button"
          >
            Demo Login
          </button>
        </form>
      </div>
    </div>
  );
};

export default withRouter(Login);