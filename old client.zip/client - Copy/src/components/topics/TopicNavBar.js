// import React from "react";
// // import { Link } from "react-router-dom"


// //code for future feature
// class TopicNavBar extends React.Component {

//   render() {
//     return (
//       <div>
//         <div className="TopicPageNavBar">
//           <ul className="list_content">
//             {/* <Link to={`/topic/${this.props.topic.name}`} className="linked_list_item">Read</Link> */}
//             {/* <Link to={`/topic/${this.props.topic.name}/questions`} className="linked_list_item">Answer</Link> */}
//             {/* <Link to="/topics/writers" className="linked_list_item">Most Viewed Writers</Link> */}
//           </ul>
//         </div>
//       </div>
//     );
//   }
// }

// export default TopicNavBar;